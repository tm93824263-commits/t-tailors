T TAILORS — ANDROID APK STARTER

This folder contains Flutter source code for an Android app prototype.
It is not an APK yet.

BUILD ON GITHUB (phone-friendly cloud build):
1. Create/sign in to a GitHub account.
2. Create a new repository named t-tailors-android.
3. Upload the CONTENTS of this folder to the repository (including the hidden .github folder).
4. Open the repository > Actions.
5. Select "Build T Tailors APK" and press "Run workflow".
6. Wait for the build to finish successfully.
7. Open the completed workflow run and download the "T-Tailors-APK" artifact.
8. Extract the downloaded artifact ZIP to get app-release.apk.
9. Open the APK on your Android phone and install it. Android may ask you to allow installs from that browser/files app.

IMPORTANT:
- This is an early UI prototype. Product data is sample data.
- Cart is temporary and stays only while the app is open.
- Login, database, real admin controls, measurement uploads, courier tracking, payment collection, push notifications and WhatsApp Business messaging are NOT connected yet.
- Do not use it to accept real customer orders until those systems are added and tested.
- Never share GitHub passwords, Google passwords, OTPs, or private API keys in chat.
